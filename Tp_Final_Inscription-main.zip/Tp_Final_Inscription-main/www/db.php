<?php

   // ICI DOIT APPARAITRE LA CONNECTION AVEC LA BASE DE DONNEES
   // ET LA GESTION DES ERREURS

$server = "localhost";
$user = "root";
$pass = "root";
$database = "tp_finaltheo";

$conn = mysqli_connect($server, $user, $pass, $database);

?>